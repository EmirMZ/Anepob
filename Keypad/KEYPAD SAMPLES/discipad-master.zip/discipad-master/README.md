# discipad
 17-key numpad assembled with only through hole components, including usb type-c

[BOM, Build Guide, and Flashing Information](./doc)

Kits available at [cftkb.com](https://www.cftkb.com)

![discipad](./doc/images/discipad.jpeg)
![](./doc/images/discipad-kicad.png)
![](./doc/images/discipad-top.png)
![](./doc/images/discipad-bottom.png)