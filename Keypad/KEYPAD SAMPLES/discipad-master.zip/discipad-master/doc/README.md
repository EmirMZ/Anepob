# DISCIPAD

[Build Guide](https://static1.squarespace.com/static/5c533d33348cd92b886e544d/t/5d90e24fbd027f6ecf7cfb2a/1569776210721/DISCIPAD+BUILD+GUIDE.pdf)

[QMK Toolbox Flashing Guide (Recommended)](https://static1.squarespace.com/static/5c533d33348cd92b886e544d/t/5d8ee3dc9135ee1aa9e99cd6/1569645533886/DISCIPAD+FLASHING+GUIDE.pdf)

[Command Line Flashing Guide (Advanced)](https://static1.squarespace.com/static/5c533d33348cd92b886e544d/t/5d8ee3c1f21a152c431c6f4b/1569645506482/DISCIPAD+FLASHING+GUIDE+-+COMMAND+LINE.pdf)

[Bootloader](./bootloader)

[BOM (Parts List)](https://octopart.com/bom-tool/zkOB9ZlB)

![discipad](./images/discipad-kicad.png)